﻿namespace E01_Logger.Enums
{
    public enum ReportLevel
    {
        Info,
        Warning,
        Error,
        Critical,
        Fatal
    }
}
